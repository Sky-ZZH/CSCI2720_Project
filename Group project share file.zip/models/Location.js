// models/Location.js
// Group: [Your Group Number]
// Student 1: [Name, ID]
// Student 2: [Name, ID]

const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema({
    title: { type: String, default: '' },
    date: { type: String, default: '' },
    time: { type: String, default: '' },
    description: { type: String, default: '' },
    presenter: { type: String, default: '' }
});

const CommentSchema = new mongoose.Schema({
    username: { type: String, required: true },
    text: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

const LocationSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    address: { type: String, default: '' },
    district: { type: String, default: '' },
    events: [EventSchema],
    comments: [CommentSchema],
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Location', LocationSchema);

