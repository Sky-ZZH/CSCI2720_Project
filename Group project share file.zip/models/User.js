// models/User.js
// Group: [Your Group Number]
// Student 1: [Name, ID]
// Student 2: [Name, ID]

const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        type: String,
        enum: ['user', 'admin'],
        default: 'user'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    favourites: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Location'
    }]
});

module.exports = mongoose.model('User', UserSchema);

