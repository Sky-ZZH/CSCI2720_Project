﻿// public/js/app.js - Final Version
console.log("✅ App.js loaded!");

// ============================================================
// STATE
// ============================================================
const state = {
    token: localStorage.getItem('token'),
    currentUser: null,
    role: null,
    locations: [],
    favourites: [],
    currentLocationId: null,
    isDarkMode: localStorage.getItem('darkMode') === 'true'
};

// ============================================================
// INITIALIZATION
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    // Theme
    if (state.isDarkMode) document.documentElement.setAttribute('data-theme', 'dark');
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Routing
    window.addEventListener('hashchange', handleRouting);

    // Modals
    setupModals();

    // Check auth
    if (state.token) {
        // Try to decode token to get username/role
        try {
            const payload = JSON.parse(atob(state.token.split('.')[1]));
            state.currentUser = payload.username;
            state.role = payload.role;
            updateNavBar();
            handleRouting();
        } catch (e) {
            logout();
        }
    } else {
        renderLogin();
    }
});

// ============================================================
// ROUTING
// ============================================================
function handleRouting() {
    const hash = window.location.hash.slice(1) || '/locations';
    const [route, id] = hash.split('/').filter(Boolean);

    if (!state.token && route !== 'login') {
        renderLogin();
        return;
    }

    // Update active nav
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    const activeLink = document.querySelector(`[href="#/${route}"]`);
    if (activeLink) activeLink.classList.add('active');

    switch (route) {
        case 'login': renderLogin(); break;
        case 'locations': renderLocations(); break;
        case 'map': renderMap(); break;
        case 'location': renderLocationDetail(id); break;
        case 'favourites': renderFavourites(); break;
        case 'admin': renderAdmin(); break;
        default: renderLocations();
    }
}

// ============================================================
// LOGIN
// ============================================================
function renderLogin() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="login-container">
            <h1>🎭 HK Cultural Events</h1>
            <p>Sign in to explore cultural venues</p>
            <div id="loginError" class="text-error" style="display:none; margin-bottom:1rem;"></div>
            <form id="loginForm">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" id="username" placeholder="testuser" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" placeholder="password123" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">Login</button>
            </form>
            <p style="margin-top:2rem; font-size:0.9rem; opacity:0.7">
                User: testuser / password123<br>
                Admin: admin / admin123
            </p>
        </div>
    `;

    document.getElementById('loginForm').onsubmit = async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await res.json();

            if (!res.ok) throw new Error(data.error);

            state.token = data.token;
            state.currentUser = data.username;
            state.role = data.role;
            localStorage.setItem('token', data.token);

            updateNavBar();
            window.location.hash = '#/locations';
        } catch (err) {
            const errDiv = document.getElementById('loginError');
            errDiv.textContent = err.message;
            errDiv.style.display = 'block';
        }
    };
}

// ============================================================
// LOCATIONS
// ============================================================
async function renderLocations() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="container">
            <h1>📍 Locations</h1>
            <div class="filters-section">
                <div class="filters-row">
                    <input type="text" id="searchInput" placeholder="Search..." oninput="filterLocations()">
                    <select id="districtSelect" onchange="filterLocations()">
                        <option value="">All Districts</option>
                        <option value="Central">Central</option>
                        <option value="Sha Tin">Sha Tin</option>
                        <option value="Tuen Mun">Tuen Mun</option>
                        <option value="Kwai Tsing">Kwai Tsing</option>
                        <option value="Yuen Long">Yuen Long</option>
                        <option value="Tsuen Wan">Tsuen Wan</option>
                        <option value="Tai Po">Tai Po</option>
                        <option value="Wong Tai Sin">Wong Tai Sin</option>
                        <option value="North">North</option>
                    </select>
                </div>
                <div class="sort-buttons">
                    <button class="btn btn-secondary" onclick="sortLocations('name')">Sort by Name</button>
                    <button class="btn btn-secondary" onclick="sortLocations('events')">Sort by Events</button>
                </div>
            </div>
            <div id="locationsList" class="locations-grid">Loading...</div>
        </div>
    `;

    await loadLocations();
}

async function loadLocations() {
    try {
        const res = await fetch('/api/locations', {
            headers: { 'Authorization': `Bearer ${state.token}` }
        });
        const data = await res.json();
        state.locations = data.locations;

        // Also load favourites to show heart status
        await loadFavourites();

        displayLocations(state.locations);
    } catch (err) {
        console.error(err);
    }
}

function displayLocations(list) {
    const div = document.getElementById('locationsList');
    if (!list.length) {
        div.innerHTML = '<p>No locations found.</p>';
        return;
    }

    div.innerHTML = list.map(loc => {
        const isFav = state.favourites.some(f => f._id === loc._id);
        return `
        <div class="location-card" onclick="goTo('${loc._id}')">
            <h3>${loc.name}</h3>
            <p><strong>District:</strong> ${loc.district}</p>
            <p><strong>Events:</strong> <span class="badge">${loc.events.length}</span></p>
            <div class="location-card-footer">
                <button class="btn btn-primary btn-small">Details</button>
                <button class="btn ${isFav ? 'btn-danger' : 'btn-secondary'} btn-small" 
                    onclick="event.stopPropagation(); toggleFav('${loc._id}')">
                    ${isFav ? '❤️ Unfav' : '🤍 Fav'}
                </button>
            </div>
        </div>
    `}).join('');
}

function filterLocations() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const district = document.getElementById('districtSelect').value;

    const filtered = state.locations.filter(l =>
        l.name.toLowerCase().includes(search) &&
        (!district || l.district === district)
    );
    displayLocations(filtered);
}

function sortLocations(type) {
    const sorted = [...state.locations];
    if (type === 'name') sorted.sort((a, b) => a.name.localeCompare(b.name));
    if (type === 'events') sorted.sort((a, b) => b.events.length - a.events.length);
    displayLocations(sorted);
}

function goTo(id) {
    window.location.hash = `#/location/${id}`;
}

// ============================================================
// DETAIL VIEW
// ============================================================
let mapInstance = null;

async function renderLocationDetail(id) {
    try {
        const res = await fetch(`/api/locations/${id}`, {
            headers: { 'Authorization': `Bearer ${state.token}` }
        });
        const loc = await res.json();

        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="detail-container">
                <a href="#/locations" class="back-button">← Back</a>
                <div class="detail-header">
                    <h1>${loc.name}</h1>
                </div>
                <div class="detail-info">
                    <p><strong>Address:</strong> ${loc.address}</p>
                    <p><strong>District:</strong> ${loc.district}</p>
                </div>
                <div id="map" class="detail-map"></div>
                
                <div class="events-section">
                    <h2>🎭 Events (${loc.events.length})</h2>
                    ${loc.events.map(e => `
                        <div class="event-item">
                            <h4>${e.title}</h4>
                            <p>📅 ${e.date} ${e.time}</p>
                            <p>${e.description}</p>
                            <p><em>By ${e.presenter}</em></p>
                        </div>
                    `).join('')}
                </div>

                <div class="comments-section">
                    <h2>💬 Comments</h2>
                    <button class="btn btn-primary" onclick="openCommentModal('${loc._id}')">Add Comment</button>
                    <div style="margin-top:1rem">
                        ${loc.comments.map(c => `
                            <div class="comment-item">
                                <p class="comment-author">${c.username}</p>
                                <p>${c.text}</p>
                                <p class="comment-time">${new Date(c.createdAt).toLocaleString()}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;

        // Map
        if (mapInstance) mapInstance.remove();
        mapInstance = L.map('map').setView([loc.lat, loc.lng], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapInstance);
        L.marker([loc.lat, loc.lng]).addTo(mapInstance).bindPopup(loc.name).openPopup();

    } catch (err) {
        console.error(err);
    }
}

// ============================================================
// FAVOURITES
// ============================================================
async function loadFavourites() {
    try {
        const res = await fetch('/api/user/favourites', {
            headers: { 'Authorization': `Bearer ${state.token}` }
        });
        state.favourites = await res.json();
    } catch (e) { }
}

async function toggleFav(id) {
    const isFav = state.favourites.some(f => f._id === id);
    const method = isFav ? 'DELETE' : 'POST';

    await fetch(`/api/user/favourites/${id}`, {
        method,
        headers: { 'Authorization': `Bearer ${state.token}` }
    });

    await loadLocations(); // Refresh list to update icons
    if (window.location.hash.includes('favourites')) renderFavourites();
}

async function renderFavourites() {
    await loadFavourites();
    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="container">
            <h1>❤️ My Favourites</h1>
            <div id="favList" class="locations-grid"></div>
        </div>
    `;

    const div = document.getElementById('favList');
    if (!state.favourites.length) {
        div.innerHTML = '<p>No favourites yet.</p>';
        return;
    }

    div.innerHTML = state.favourites.map(loc => `
        <div class="location-card" onclick="goTo('${loc._id}')">
            <h3>${loc.name}</h3>
            <p><strong>District:</strong> ${loc.district}</p>
            <div class="location-card-footer">
                <button class="btn btn-primary btn-small">Details</button>
                <button class="btn btn-danger btn-small" 
                    onclick="event.stopPropagation(); toggleFav('${loc._id}')">Remove</button>
            </div>
        </div>
    `).join('');
}

// ============================================================
// MAP VIEW (ALL)
// ============================================================
async function renderMap() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="container">
            <h1>🗺️ Map View</h1>
            <div id="map" class="detail-map" style="height:600px"></div>
        </div>
    `;

    if (!state.locations.length) await loadLocations();

    if (mapInstance) mapInstance.remove();
    const center = [22.3193, 114.1694];
    mapInstance = L.map('map').setView(center, 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapInstance);

    state.locations.forEach(loc => {
        L.marker([loc.lat, loc.lng]).addTo(mapInstance)
            .bindPopup(`<b>${loc.name}</b><br><button onclick="goTo('${loc._id}')">View</button>`);
    });
}

// ============================================================
// ADMIN
// ============================================================
async function renderAdmin() {
    if (state.role !== 'admin') {
        document.getElementById('app').innerHTML = '<h1>Access Denied</h1>';
        return;
    }

    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="container">
            <h1>🛡️ Admin Dashboard</h1>
            <div class="admin-container">
                <div class="admin-section">
                    <h2>Locations</h2>
                    <button class="btn btn-primary" onclick="openAdminModal()">+ New Location</button>
                    <div id="adminLocs" style="margin-top:1rem">Loading...</div>
                </div>
                <div class="admin-section">
                    <h2>Users</h2>
                    <div id="adminUsers" style="margin-top:1rem">Loading...</div>
                </div>
            </div>
        </div>
    `;

    loadAdminData();
}

async function loadAdminData() {
    // Locations
    const resLoc = await fetch('/api/locations', { headers: { 'Authorization': `Bearer ${state.token}` } });
    const dataLoc = await resLoc.json();
    document.getElementById('adminLocs').innerHTML = dataLoc.locations.map(l => `
        <div class="admin-item" style="border-bottom:1px solid #ccc; padding:10px; display:flex; justify-content:space-between">
            <span>${l.name}</span>
            <button class="btn btn-danger btn-small" onclick="deleteLoc('${l._id}')">Delete</button>
        </div>
    `).join('');

    // Users
    const resUser = await fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${state.token}` } });
    const users = await resUser.json();
    document.getElementById('adminUsers').innerHTML = users.map(u => `
        <div class="admin-item" style="border-bottom:1px solid #ccc; padding:10px; display:flex; justify-content:space-between">
            <span>${u.username} (${u.role})</span>
            ${u.username !== 'admin' ? `<button class="btn btn-danger btn-small" onclick="deleteUser('${u._id}')">Delete</button>` : ''}
        </div>
    `).join('');
}

async function deleteLoc(id) {
    if (!confirm('Delete?')) return;
    await fetch(`/api/admin/locations/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${state.token}` } });
    loadAdminData();
}

async function deleteUser(id) {
    if (!confirm('Delete?')) return;
    await fetch(`/api/admin/users/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${state.token}` } });
    loadAdminData();
}

// ============================================================
// UTILS & MODALS
// ============================================================
function updateNavBar() {
    document.getElementById('logoutBtn').style.display = state.token ? 'block' : 'none';
    document.getElementById('adminLink').style.display = state.role === 'admin' ? 'block' : 'none';
    document.getElementById('userDisplay').textContent = state.currentUser ? `👤 ${state.currentUser}` : '';
}

function logout() {
    state.token = null;
    localStorage.removeItem('token');
    window.location.hash = '#/login';
    renderLogin();
}

function toggleTheme() {
    state.isDarkMode = !state.isDarkMode;
    document.documentElement.setAttribute('data-theme', state.isDarkMode ? 'dark' : 'light');
    localStorage.setItem('darkMode', state.isDarkMode);
}

function setupModals() {
    // Basic modal close logic
    window.onclick = (e) => {
        if (e.target.classList.contains('modal')) e.target.classList.remove('show');
    };
    document.querySelectorAll('.close').forEach(b => b.onclick = () => {
        document.querySelectorAll('.modal').forEach(m => m.classList.remove('show'));
    });
}

function openCommentModal(id) {
    const m = document.getElementById('commentModal');
    m.classList.add('show');
    document.getElementById('commentForm').onsubmit = async (e) => {
        e.preventDefault();
        const text = document.getElementById('commentText').value;
        await fetch(`/api/locations/${id}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${state.token}` },
            body: JSON.stringify({ text })
        });
        document.getElementById('commentText').value = '';
        m.classList.remove('show');
        renderLocationDetail(id);
    };
}

function openAdminModal() {
    const m = document.getElementById('adminModal');
    m.classList.add('show');
    document.getElementById('adminForm').onsubmit = async (e) => {
        e.preventDefault();
        const body = {
            name: document.getElementById('adminName').value,
            lat: document.getElementById('adminLat').value,
            lng: document.getElementById('adminLng').value,
            district: document.getElementById('adminDistrict').value,
            address: document.getElementById('adminAddress').value
        };
        await fetch('/api/admin/locations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${state.token}` },
            body: JSON.stringify(body)
        });
        m.classList.remove('show');
        loadAdminData();
    };
}
