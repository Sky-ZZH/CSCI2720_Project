﻿require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static('public'));

// ===== CONFIG =====
const MONGO_URI = 'mongodb://127.0.0.1:27017/csci2720_project';
const JWT_SECRET = 'csci2720_secret_key';
const PORT = 3000;

// ===== MONGOOSE SCHEMAS =====
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    favourites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Location' }],
    createdAt: { type: Date, default: Date.now }
});

const LocationSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    address: { type: String, default: '' },
    district: { type: String, default: '' },
    events: [{
        title: String,
        date: String,
        time: String,
        description: String,
        presenter: String
    }],
    comments: [{
        username: String,
        text: String,
        createdAt: { type: Date, default: Date.now }
    }],
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Location = mongoose.model('Location', LocationSchema);

// ===== CONNECT MONGODB =====
let lastDataUpdateTime = null;

mongoose.connect(MONGO_URI)
    .then(() => {
        console.log('✅ MongoDB Connected');
        initializeData();
    })
    .catch(err => console.error('❌ MongoDB Error:', err));

// ===== INITIALIZE DATA =====
async function initializeData() {
    try {
        // Create test users
        const userCount = await User.countDocuments();
        if (userCount === 0) {
            console.log('📝 Creating test users...');

            const testUserHash = await bcrypt.hash('password123', 10);
            const adminHash = await bcrypt.hash('admin123', 10);

            await User.insertMany([
                { username: 'testuser', password: testUserHash, role: 'user', favourites: [] },
                { username: 'admin', password: adminHash, role: 'admin', favourites: [] }
            ]);

            console.log('✅ Test users created');
            console.log('   User: testuser / password123');
            console.log('   Admin: admin / admin123');
        }

        // Create test locations with 3-5 events each
        const locCount = await Location.countDocuments();
        if (locCount === 0) {
            console.log('📝 Creating test locations...');

            const locations = [
                {
                    name: 'Hong Kong Cultural Centre',
                    lat: 22.2936,
                    lng: 114.1704,
                    district: 'Central',
                    address: 'Salisbury Road, Tsim Sha Tsui',
                    events: [
                        { title: 'Classical Music Concert', date: '2025-12-20', time: '19:30', description: 'Evening of classical masterpieces', presenter: 'HK Philharmonic' },
                        { title: 'Ballet Performance', date: '2025-12-25', time: '20:00', description: 'Contemporary ballet showcase', presenter: 'City Contemporary Dance' },
                        { title: 'Jazz Night', date: '2025-12-28', time: '21:00', description: 'Live jazz performances', presenter: 'Local Jazz Artists' },
                        { title: 'Traditional Opera', date: '2026-01-05', time: '19:00', description: 'Cantonese opera performance', presenter: 'Hong Kong Opera' }
                    ]
                },
                {
                    name: 'City Hall',
                    lat: 22.2825,
                    lng: 114.1620,
                    district: 'Central',
                    address: 'Edinburgh Place, Central',
                    events: [
                        { title: 'Chamber Music Series', date: '2025-12-22', time: '14:30', description: 'Intimate chamber music performances', presenter: 'Classical Ensemble' },
                        { title: 'Piano Recital', date: '2025-12-29', time: '19:00', description: 'Solo piano performances', presenter: 'International Pianist' },
                        { title: 'Contemporary Art Exhibition', date: '2026-01-10', time: '10:00', description: 'Modern art showcase', presenter: 'Arts HK' }
                    ]
                },
                {
                    name: 'Sha Tin Town Hall',
                    lat: 22.3952,
                    lng: 114.1855,
                    district: 'Sha Tin',
                    address: 'Pai Tau Street, Sha Tin',
                    events: [
                        { title: 'Community Cultural Festival', date: '2025-12-27', time: '15:00', description: 'Local cultural performances', presenter: 'Sha Tin Community' },
                        { title: 'Youth Music Festival', date: '2026-01-15', time: '18:00', description: 'Young musicians showcase', presenter: 'Music Education HK' },
                        { title: 'Traditional Crafts Workshop', date: '2026-01-20', time: '14:00', description: 'Learn traditional HK crafts', presenter: 'Heritage Foundation' }
                    ]
                },
                {
                    name: 'Tuen Mun Town Hall',
                    lat: 22.4084,
                    lng: 113.9756,
                    district: 'Tuen Mun',
                    address: 'Tuen Mun Road, Tuen Mun',
                    events: [
                        { title: 'Folk Music Night', date: '2025-12-21', time: '19:30', description: 'Traditional folk performances', presenter: 'Folk Music Society' },
                        { title: 'Dance Workshop', date: '2026-01-08', time: '18:00', description: 'Learn contemporary dance', presenter: 'Dance Academy' },
                        { title: 'Comedy Show', date: '2026-01-25', time: '20:00', description: 'Stand-up comedy night', presenter: 'Local Comedians' },
                        { title: 'Film Screening', date: '2026-02-01', time: '19:00', description: 'Independent film showcase', presenter: 'Film Club HK' }
                    ]
                },
                {
                    name: 'Kwai Tsing Theatre',
                    lat: 22.3098,
                    lng: 114.1279,
                    district: 'Kwai Tsing',
                    address: 'Ling Tung Street, Kwai Chung',
                    events: [
                        { title: 'Drama Production', date: '2025-12-26', time: '19:00', description: 'Theatrical drama production', presenter: 'Local Theatre Group' },
                        { title: 'Musical Performance', date: '2026-01-12', time: '19:30', description: 'Musical theatre performance', presenter: 'Broadway Stars' },
                        { title: 'Children Concert', date: '2026-01-18', time: '14:00', description: 'Family-friendly concert', presenter: 'Young Performers' }
                    ]
                },
                {
                    name: 'Yuen Long Theatre',
                    lat: 22.4459,
                    lng: 114.0113,
                    district: 'Yuen Long',
                    address: 'Castle Peak Road, Yuen Long',
                    events: [
                        { title: 'orchestral Concert', date: '2025-12-30', time: '19:30', description: 'Full orchestral performance', presenter: 'City Philharmonic' },
                        { title: 'Contemporary Dance', date: '2026-01-22', time: '20:00', description: 'Modern dance showcase', presenter: 'Dance Collective' },
                        { title: 'Cantonese Opera', date: '2026-02-05', time: '19:00', description: 'Traditional Cantonese opera', presenter: 'Opera Heritage' },
                        { title: 'International Music Festival', date: '2026-02-14', time: '18:00', description: 'Music from around the world', presenter: 'Global Artists' }
                    ]
                },
                {
                    name: 'Tsuen Wan Town Hall',
                    lat: 22.3126,
                    lng: 114.0962,
                    district: 'Tsuen Wan',
                    address: 'Wo Wo Street, Tsuen Wan',
                    events: [
                        { title: 'String Quartet Performance', date: '2026-01-02', time: '19:00', description: 'Classic string quartet', presenter: 'String Ensemble' },
                        { title: 'Violin Recital', date: '2026-01-28', time: '19:30', description: 'Virtuoso violin performance', presenter: 'Violin Master' },
                        { title: 'Asian Music Festival', date: '2026-02-10', time: '18:00', description: 'Music from Asia', presenter: 'Asian Arts' }
                    ]
                },
                {
                    name: 'Tai Po Civic Centre',
                    lat: 22.4513,
                    lng: 114.1707,
                    district: 'Tai Po',
                    address: 'Ting Kok Road, Tai Po',
                    events: [
                        { title: 'Woodwind Ensemble Concert', date: '2026-01-03', time: '14:30', description: 'Woodwind instruments showcase', presenter: 'Wind Ensemble' },
                        { title: 'Jazz Fusion Night', date: '2026-02-08', time: '19:30', description: 'Jazz fusion performances', presenter: 'Fusion Band' },
                        { title: 'Modern Theatre', date: '2026-02-20', time: '19:00', description: 'Contemporary theatrical production', presenter: 'Modern Theatre Co' }
                    ]
                },
                {
                    name: 'Ko Shan Theatre',
                    lat: 22.3292,
                    lng: 114.1748,
                    district: 'Wong Tai Sin',
                    address: 'Lung Cheung Road, Wong Tai Sin',
                    events: [
                        { title: 'Brass Band Concert', date: '2026-01-06', time: '19:00', description: 'Brass band performance', presenter: 'Brass Ensemble' },
                        { title: 'Electric Music Festival', date: '2026-02-03', time: '20:00', description: 'Electronic music showcase', presenter: 'Electronic Artists' },
                        { title: 'Classical Ballet', date: '2026-02-23', time: '19:30', description: 'Ballet classic performance', presenter: 'Ballet Company' },
                        { title: 'Music Lecture Series', date: '2026-03-01', time: '15:00', description: 'Music history and theory', presenter: 'Music Professor' }
                    ]
                },
                {
                    name: 'North District Town Hall',
                    lat: 22.5065,
                    lng: 114.1333,
                    district: 'North',
                    address: 'Heung Shan Road, Sheung Shui',
                    events: [
                        { title: 'Percussion Concert', date: '2026-01-09', time: '14:00', description: 'Percussion instruments showcase', presenter: 'Percussion Group' },
                        { title: 'Soul Music Night', date: '2026-02-12', time: '19:30', description: 'Soul and R&B performances', presenter: 'Soul Singers' },
                        { title: 'Comedy & Music Show', date: '2026-02-28', time: '19:00', description: 'Comedy with live music', presenter: 'Entertainment HK' }
                    ]
                }
            ];

            await Location.insertMany(locations);
            console.log('✅ Test locations created (10 venues with 3-5 events each)');
        }

        lastDataUpdateTime = new Date();
    } catch (error) {
        console.error('❌ Error initializing data:', error.message);
    }
}

// ===== MIDDLEWARE =====
function verifyToken(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token' });

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
}

function verifyAdmin(req, res, next) {
    verifyToken(req, res, () => {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ error: 'Admin only' });
        }
        next();
    });
}

// ===== AUTH ROUTES =====
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).json({ error: 'Missing credentials' });
        }

        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user._id, username: user.username, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ token, username: user.username, role: user.role, userId: user._id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/logout', (req, res) => {
    res.json({ message: 'Logged out' });
});

// ===== LOCATION ROUTES =====
app.get('/api/locations', verifyToken, async (req, res) => {
    try {
        const { search = '', district = '', sort = 'name' } = req.query;
        let query = {};
        if (search) query.name = { $regex: search, $options: 'i' };
        if (district) query.district = district;

        let locations = await Location.find(query);

        // Sorting
        if (sort === 'name') {
            locations.sort((a, b) => a.name.localeCompare(b.name));
        } else if (sort === 'events') {
            locations.sort((a, b) => b.events.length - a.events.length);
        }

        res.json({
            locations,
            count: locations.length,
            lastUpdated: lastDataUpdateTime || new Date()
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/locations/:id', verifyToken, async (req, res) => {
    try {
        const location = await Location.findById(req.params.id);
        if (!location) return res.status(404).json({ error: 'Not found' });
        res.json(location);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/locations/:id/comments', verifyToken, async (req, res) => {
    try {
        const { text } = req.body;
        if (!text) return res.status(400).json({ error: 'Text required' });

        const location = await Location.findByIdAndUpdate(
            req.params.id,
            { $push: { comments: { username: req.user.username, text, createdAt: new Date() } } },
            { new: true }
        );
        res.json(location);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== FAVOURITES ROUTES =====
app.get('/api/user/favourites', verifyToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).populate('favourites');
        res.json(user.favourites || []);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/user/favourites/:locationId', verifyToken, async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(
            req.user.id,
            { $addToSet: { favourites: req.params.locationId } },
            { new: true }
        ).populate('favourites');
        res.json(user.favourites);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/user/favourites/:locationId', verifyToken, async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(
            req.user.id,
            { $pull: { favourites: req.params.locationId } },
            { new: true }
        ).populate('favourites');
        res.json(user.favourites);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== ADMIN ROUTES: LOCATIONS =====
app.post('/api/admin/locations', verifyAdmin, async (req, res) => {
    try {
        const { name, lat, lng, address, district, events } = req.body;
        const location = new Location({
            name,
            lat,
            lng,
            address,
            district,
            events: events || []
        });
        await location.save();
        res.status(201).json(location);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.put('/api/admin/locations/:id', verifyAdmin, async (req, res) => {
    try {
        const location = await Location.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.json(location);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.delete('/api/admin/locations/:id', verifyAdmin, async (req, res) => {
    try {
        await Location.findByIdAndDelete(req.params.id);
        res.json({ message: 'Location deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== ADMIN ROUTES: USERS =====
app.get('/api/admin/users', verifyAdmin, async (req, res) => {
    try {
        const users = await User.find({}, { password: 0 });
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/admin/users', verifyAdmin, async (req, res) => {
    try {
        const { username, password, role } = req.body;
        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password required' });
        }

        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({
            username,
            password: hashedPassword,
            role: role || 'user'
        });
        await user.save();
        res.status(201).json({ id: user._id, username: user.username, role: user.role });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.delete('/api/admin/users/:id', verifyAdmin, async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.id);
        res.json({ message: 'User deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ===== START SERVER =====
app.listen(PORT, () => {
    console.log(`\n🚀 Server running on http://localhost:${PORT}\n`);
});

// SPA Fallback
app.get('*', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});
